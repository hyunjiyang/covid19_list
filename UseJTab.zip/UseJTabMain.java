class  UseJTabMain
{
	public static void main(String[] args) 
	{
		new UseJTab();
	}
}