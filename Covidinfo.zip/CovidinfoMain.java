
public class  CovidinfoMain
{
	public static void main(String[] args) 
	{
		new Covidinfo();
	}
}